from time_series_visualizer import draw_line_plot, draw_bar_plot, draw_box_plot

# Generate plots
draw_line_plot()
draw_bar_plot()
draw_box_plot()
